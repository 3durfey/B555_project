This folder contains Hui's approach for this metaphor detection model. This is not the best performing model in our group, therefore, it is only provided to show my work:)

The output model of run_test.py is named as model_Hui.pt 

Model Performance on held-out testing set(20%): 

Evaluation Results:
Accuracy  : 0.8235
Precision : 0.7835
Recall    : 0.7531
F1 (macro): 0.7655